package trabalhophp.model;

import java.time.LocalDate;

public class Engenheiro {

    private int codigo;
    private String nome;
    private String crea;
    private String email;
    private LocalDate dataAdmissao;

    public Engenheiro() {
    }

    public Engenheiro(int codigo, String nome, String crea, String email, LocalDate dataAdmissao) {
        this.codigo = codigo;
        this.nome = nome;
        this.crea = crea;
        this.email = email;
        this.dataAdmissao = dataAdmissao;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCrea() {
        return crea;
    }

    public void setCrea(String crea) {
        this.crea = crea;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(LocalDate dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }
}
